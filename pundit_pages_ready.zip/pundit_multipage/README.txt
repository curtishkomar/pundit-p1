PUNDIT MULTI-PAGE HOMEPAGE

Open index.html in a browser to view the dashboard. Click a module card or sidebar link to open its own page.

Terminal is currently a safe visual preview only. Real command execution requires a secure authenticated backend on the server; no commands are executed by these static HTML files.

Keep style.css in the same folder as all HTML files.
